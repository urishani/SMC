package com.ibm.rhapsody.plugins;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.ibm.rhapsody.concise.common.NameModifier;

import freemarker.cache.ClassTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.ObjectWrapper;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;

public class RhpTemplateConfiguration extends Configuration {
	public RhpTemplateConfiguration() {
        // - Templates are stoted in the WEB-INF/templates directory of the Web app.
        //this.setServletContextForTemplateLoading(
        //        getServletContext(), "WEB-INF/templates");
        // - Set update dealy to 0 for now, to ease debugging and testing.
        //   Higher value should be used in production environment.
        this.setTemplateUpdateDelay(0);
        // - Set an error handler that prints errors so they are readable with
        //   a HTML browser.
        this.setTemplateExceptionHandler(
                TemplateExceptionHandler.DEBUG_HANDLER);
        // - Use beans wrapper (recommmended for most applications)
        this.setObjectWrapper(ObjectWrapper.BEANS_WRAPPER);
        // - Set the default charset of the template files
        this.setDefaultEncoding("ISO-8859-1");
        // - Set the charset of the output. This is actually just a hint, that
        //   templates may require for URL encoding and for generating META element
        //   that uses http-equiv="Content-type".
        this.setOutputEncoding("UTF-8");
        // - Set the default locale
        this.setLocale(Locale.US);
        
        // Set template loader from the project resources
		this.setTemplateLoader(new ClassTemplateLoader(getClass(), "/"));
	}
	
	public void applyTemplate(Object model, String baseFileName, String templatePrefix, String ext) throws IOException, TemplateException {
		String modFileName = baseFileName + ext;
		FileWriter out = new FileWriter(new File(modFileName));
		applyTemplate(model, out, templatePrefix + ext);
	}

	public void applyTemplate(Object model, Writer out, String templateName) throws IOException, TemplateException {
		Map<String, Object> root = new HashMap<String, Object>();
		root.put("model", model);
		root.put("typeMod", new NameModifier() {
			public String alter(String typeName) {
				if("RhpInteger".equals(typeName))
					return "int";
				if("RhpReal".equals(typeName))
					return "float";
				if("RhpBoolean".equals(typeName))
					return "boolean"; // string???
				if("RhpString".equals(typeName))
					return "string";
				return typeName;
			}});

		Template t = this.getTemplate(templateName);
		t.process(root, out);
	}
}
