package com.ibm.rhapsody.sprint.plugin;

import java.io.PrintStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import com.telelogic.rhapsody.core.IRPModelElement;


/**
 * Create elements and serialize them as RDF resources.<p>
 * Use these methods:<br>
 * <ol>
 * <li>Element(part) creates the part for a certain GUID, and sets up some literal properties.
 * <li>AddRelation(prop, part) - adds a relation with property prop, and for another element
 * <li>AddProperty(prop, val) - adds a literal property.
 * @author shani
 *
 */
public class Element extends HashMap<String, Object> {
	public final static String  RHP_MODEL_PREFIX = "rhp_model";
	public final static String  RHP_MODEL_NS = "http://com.ibm.rhapsody/sprint/";
	public final static String  TITLE = "dc:title";
	public final static String  CLASS = "rdf:type";
	public final static String  SPRINT_RESOURCE = RHP_MODEL_PREFIX +":hasSprintResource";
	public final static String  VERSION = RHP_MODEL_PREFIX +":version";
	public final static String  MULTIPLICITY = RHP_MODEL_PREFIX +":hasMultiplicity";
	public final static String  VISIBILITY = RHP_MODEL_PREFIX +":hasVisibility";
	public final static String  DESCRIPTION = "dc:description";
	
	private static final long serialVersionUID = -7322031395610497151L;
	private final String m_guid;
	public static String[] sInlineAtts = new String[] {TITLE, VERSION};
	public static String[] sResourceAtts = new String[] {VISIBILITY, MULTIPLICITY};
	
	public Element(IRPModelElement element, Properties sii_guid_mapping) {
		m_guid = getGUID(element);
		String metaClass = element.getUserDefinedMetaClass();
		put(TITLE, element.getName());
		String description = element.getDescriptionHTML();
		if (null != description && false == "".equals(description.trim()))
			put(DESCRIPTION, description);
		put(CLASS, metaClass);
		String siiUri = sii_guid_mapping.getProperty(getGUID(element)); //part.getPropertyValueExplicit(IRhpConstants.SII_URI);
		if (null != siiUri) 
			put(SPRINT_RESOURCE, siiUri);
	}

	public void addRelation(String prop, IRPModelElement part) {
		addResourceProperty(prop, RHP_MODEL_NS + getGUID(part));
	}
	
	public void addProperty(String property, String value) {
		put(property, RHP_MODEL_PREFIX + ":" + value);
	}

	@SuppressWarnings("unchecked")
	private void addResourceProperty(String prop, String value) {
		Set<String> values = (Set<String>) get(prop);
		if (null == values) {
			values = new HashSet<String>();
			put(prop, values);
		}
		values.add(value);
	}

	/**
	 * Serializes the element into an RDF resource in RDF/XML format.
	 * @return String of the serialized element
	 */
	@SuppressWarnings("unchecked")
	public String serialize() {
		StringBuffer result = new StringBuffer(
				"<rdf:Description rdf:about=\"" + RHP_MODEL_PREFIX + ":" + m_guid + "\"\n   ");
		Set<String> atts = keySet();
		List<String> inlines = Arrays.asList(sInlineAtts);
		List<String> resources = Arrays.asList(sResourceAtts);
		for (String att : atts) {
			if (inlines.contains(att)) {
				String val =  get(att).toString();
				result.append(att + "=\"" + val + "\"\n   ");
			}
		}
		result.append(">\n   ");
		for (String att : atts) {
			if (inlines.contains(att))
				continue;
			Object val = get(att);
			if (val instanceof String) {
				if (resources.contains(att)) {
					result.append("<" + att + " rdf:resource=\"" + RHP_MODEL_NS + val + "\"/>\n   ");
				} else
					result.append("<" + att + ">\n      " + val + "\n   </" + att + ">\n   ");
			} else if (val instanceof Set<?>) {
				Set<String>valSet = (Set<String>)val;
				if (valSet.size() > 0) {
					for (String value : valSet) {
						result.append("<" + att + 
								" rdf:resource=\"" + value + "\"/>\n   ");
					}
				}
			}
			result.append("</rdf:Description>\n");
		}
		return result.toString();
	}

	/**
	 * Generates a GUID that can be valid as part of a URI
	 * @param part a Rhapsody element
	 * @return String for the modified GUID of that element.
	 */
	public static String getGUID(IRPModelElement part) {
		String guid = part.getGUID();
		return guid.replace(' ', '-');
	}
	
	public static String getHeader() {
		return 	
				"<?xml version=\"1.0\"?>\n" +
				"<rdf:RDF\nxmlns:" + RHP_MODEL_PREFIX + 
				"=\"" + RHP_MODEL_NS + "\"\n" +
				"xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n" +
				"xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n";
	}
	
	public static String getFooter() {
		return "</rdf:RDF>";
	}
	
	/**
	 * Either use this method, or take it as an example for producing the output file.
	 * @param elements List of elements to be serialized.
	 * @param out PrintStream to serialize to.
	 */
	public static void serializeAll(Collection<Element> elements, PrintStream out) {
		out.print(getHeader());
		for (Element element : elements) {
			out.print(element.serialize());
		}
		out.print(getFooter());
		out.close();
	}
}
