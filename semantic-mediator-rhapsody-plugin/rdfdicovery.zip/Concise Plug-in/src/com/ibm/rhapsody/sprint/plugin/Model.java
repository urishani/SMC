package com.ibm.rhapsody.sprint.plugin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.telelogic.rhapsody.core.IRPAssociationClass;
import com.telelogic.rhapsody.core.IRPAttribute;
import com.telelogic.rhapsody.core.IRPClass;
import com.telelogic.rhapsody.core.IRPClassifier;
import com.telelogic.rhapsody.core.IRPCollection;
import com.telelogic.rhapsody.core.IRPComponent;
import com.telelogic.rhapsody.core.IRPDependency;
import com.telelogic.rhapsody.core.IRPFlow;
import com.telelogic.rhapsody.core.IRPInstance;
import com.telelogic.rhapsody.core.IRPLink;
import com.telelogic.rhapsody.core.IRPModelElement;
import com.telelogic.rhapsody.core.IRPPackage;
import com.telelogic.rhapsody.core.IRPProject;
import com.telelogic.rhapsody.core.IRPStereotype;

public class Model {
	private final IRPProject project;
	private final Map<String, Element> elements = new HashMap<String, Element>();
	private final LinkedList<IRPModelElement> traversalQueue = new LinkedList<IRPModelElement>();

	public Model(IRPProject project) {
		this.project = project;
	}

	public IRPProject getProject() {
		return project;
	}
	
	// Factory function
	public Element getElement(IRPModelElement modelElement) {
		Element element = elements.get(modelElement.getGUID());
		if(element == null) {
			element = new Element(modelElement, new Properties()); // TBD: Properties???
			elements.put(modelElement.getGUID(), element);
		}
		return element;
	}
	
	public boolean hasElement(IRPModelElement modelElement) {
		return elements.containsKey(modelElement.getGUID());
	}

	public Collection<Element> queryElements(String query) {
		return elements.values(); // Until we figure what queries are expected to arrive, if any
	}
	
	public String getRDFHeader() {
		return Element.getHeader();
	}
	
	public String getRDFFooter() {
		return Element.getFooter();
	}
	
	public Collection<IRPModelElement> getRhpElements(String query) {
        ArrayList<IRPModelElement> list = new ArrayList<IRPModelElement>();
        list.add(project);
		return list;
	}
	
	public String pushTraversalQueue(IRPModelElement element) {
		traversalQueue.push(element);
		return "";
	}
	
	public IRPModelElement popTraversalQueue() {
		return traversalQueue.pollLast();
	}
	
	public void addRelation(Element element, String relation, IRPModelElement other) {
		if(other != null) {
			element.addRelation(relation, other);
			pushTraversalQueue(other);
		}
	}
	
	public void addRelations(Element element, String relation, Collection<IRPModelElement> others) {
		for(IRPModelElement other: others)
			addRelation(element, relation, other);
	}
	
	public void addProperty(Element element, String property, String value) {
		element.addProperty(property, value);
	}
	
	public Collection<IRPModelElement> asCollection(IRPCollection irpCollection) {
		ArrayList<IRPModelElement> list = new ArrayList<IRPModelElement>();
		for(Object irpModelElement: irpCollection.toList()) {
			list.add((IRPModelElement) irpModelElement);
		}
		return list;
	}
	
	public boolean isIRPProject(IRPModelElement element) {
		return element instanceof IRPProject;
	}
	
	public IRPProject asIRPIRPProject(IRPModelElement element) {
		return (IRPProject) element;
	}
	
	public boolean isIRPClassifier(IRPModelElement element) {
		return element instanceof IRPClassifier;
	}
	
	public IRPClassifier asIRPClassifier(IRPModelElement element) {
		return (IRPClassifier) element;
	}
	
	public boolean isIRPInstance(IRPModelElement element) {
		return element instanceof IRPInstance;
	}
	
	public IRPInstance asIRPInstance(IRPModelElement element) {
		return (IRPInstance) element;
	}
	
	public boolean isIRPLink(IRPModelElement element) {
		return element instanceof IRPLink;
	}
	
	public IRPLink asIRPLink(IRPModelElement element) {
		return (IRPLink) element;
	}
	
	public boolean isIRPDependency(IRPModelElement element) {
		return element instanceof IRPDependency;
	}
	
	public IRPDependency asIRPDependency(IRPModelElement element) {
		return (IRPDependency) element;
	}
	
	public boolean isIRPFlow(IRPModelElement element) {
		return element instanceof IRPFlow;
	}
	
	public IRPFlow asIRPFlow(IRPModelElement element) {
		return (IRPFlow) element;
	}
	
	public boolean isIRPAttribute(IRPModelElement element) {
		return element instanceof IRPAttribute;
	}
	
	public IRPAttribute asIRPAttribute(IRPModelElement element) {
		return (IRPAttribute) element;
	}
	
	public boolean isIRPAssociationClass(IRPModelElement element) {
		return element instanceof IRPAssociationClass;
	}
	
	public IRPAssociationClass asIRPAssociationClass(IRPModelElement element) {
		return (IRPAssociationClass) element;
	}
	
	public boolean isIRPClass(IRPModelElement element) {
		return element instanceof IRPClass;
	}
	
	public IRPClass asIRPClass(IRPModelElement element) {
		return (IRPClass) element;
	}
	
	public boolean isIRPStereotype(IRPModelElement element) {
		return element instanceof IRPStereotype;
	}
	
	public IRPStereotype asIRPStereotype(IRPModelElement element) {
		return (IRPStereotype) element;
	}
	
	public boolean isIRPPackage(IRPModelElement element) {
		return element instanceof IRPPackage;
	}
	
	public IRPPackage asIRPPackage(IRPModelElement element) {
		return (IRPPackage) element;
	}
	
	public boolean isIRPComponent(IRPModelElement element) {
		return element instanceof IRPComponent;
	}
	
	public IRPComponent asIRPComponent(IRPModelElement element) {
		return (IRPComponent) element;
	}
	
	public boolean isIRPModelElement(Object element) {
		System.out.println("q: " + traversalQueue.size() + ", element:" + (element==null?"null":element.getClass().getName()));
		return element != null && element instanceof IRPModelElement;
	}
	
	//-------------------------------------------------
	public Collection<IRPModelElement> getParts(IRPClass aClass) {
		List<IRPModelElement> result = new LinkedList<IRPModelElement>();
		for (Object element : aClass.getRelations().toList()) {
			if (element instanceof IRPInstance)
				result.add((IRPModelElement) element);
		}
		return result;
	}
}
