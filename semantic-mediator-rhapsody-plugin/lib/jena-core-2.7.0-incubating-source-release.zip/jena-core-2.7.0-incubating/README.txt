Jena2 README
============

Welcome to Apache Jena,  a Java framework for 
writing Semantic Web applications.

The full readme is in doc/readme.html. 

Documentation can be found on the web at
http://incubator.apache.org/jena

There is a mailing lists for questions and feedback:
jena-users@incubator.apache.org

